/*
* Generated S-function Target for model InverterTwF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 10:51:13 2017
*/

#ifndef RTWSFCN_InverterTwF_sf_H
#define RTWSFCN_InverterTwF_sf_H

#include "InverterTwF_sfcn_rtw\InverterTwF_sf.h"
  #include "InverterTwF_sfcn_rtw\InverterTwF_sf_private.h"

#endif
