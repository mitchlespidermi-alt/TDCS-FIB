/*
 * Generated S-function Target for model InverterTwF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 10:51:13 2017
 */

#include "InverterTwF_sf.h"
#include "InverterTwF_sfcn_rtw\InverterTwF_sf.c"


