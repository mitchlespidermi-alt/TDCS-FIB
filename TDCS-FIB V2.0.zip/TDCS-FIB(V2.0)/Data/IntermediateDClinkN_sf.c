/*
 * Generated S-function Target for model IntermediateDClinkN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:25:25 2017
 */

#include "IntermediateDClinkN_sf.h"
#include "IntermediateDClinkN_sfcn_rtw\IntermediateDClinkN_sf.c"


