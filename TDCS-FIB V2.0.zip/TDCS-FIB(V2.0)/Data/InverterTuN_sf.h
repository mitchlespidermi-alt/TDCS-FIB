/*
* Generated S-function Target for model InverterTuN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:24:22 2017
*/

#ifndef RTWSFCN_InverterTuN_sf_H
#define RTWSFCN_InverterTuN_sf_H

#include "InverterTuN_sfcn_rtw\InverterTuN_sf.h"
  #include "InverterTuN_sfcn_rtw\InverterTuN_sf_private.h"

#endif
