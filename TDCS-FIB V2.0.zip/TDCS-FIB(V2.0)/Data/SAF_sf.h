/*
* Generated S-function Target for model SAF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:15:36 2017
*/

#ifndef RTWSFCN_SAF_sf_H
#define RTWSFCN_SAF_sf_H

#include "SAF_sfcn_rtw\SAF_sf.h"
  #include "SAF_sfcn_rtw\SAF_sf_private.h"

#endif
