/*
 * Generated S-function Target for model SFI0. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Wed Apr 06 14:43:03 2016
 */

#include "SFI0_sf.h"
#include "SFI0_sfcn_rtw\SFI0_sf.c"
#include "SFI0_sfcn_rtw\SFI0_sf_data.c"


