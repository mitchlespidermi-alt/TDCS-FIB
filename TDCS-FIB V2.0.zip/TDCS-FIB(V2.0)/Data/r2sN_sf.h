/*
* Generated S-function Target for model r2sN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon Jul 24 15:37:15 2017
*/

#ifndef RTWSFCN_r2sN_sf_H
#define RTWSFCN_r2sN_sf_H

#include "r2sN_sfcn_rtw\r2sN_sf.h"
  #include "r2sN_sfcn_rtw\r2sN_sf_private.h"

#endif
