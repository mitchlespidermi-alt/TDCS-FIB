/*
 * Generated S-function Target for model SAF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:15:36 2017
 */

#include "SAF_sf.h"
#include "SAF_sfcn_rtw\SAF_sf.c"


