/*
 * Generated S-function Target for model MeasurementF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:18:47 2017
 */

#include "MeasurementF_sf.h"
#include "MeasurementF_sfcn_rtw\MeasurementF_sf.c"
#include "MeasurementF_sfcn_rtw\MeasurementF_sf_data.c"


