/*
* Generated S-function Target for model RecSubSubF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:16:51 2017
*/

#ifndef RTWSFCN_RecSubSubF_sf_H
#define RTWSFCN_RecSubSubF_sf_H

#include "RecSubSubF_sfcn_rtw\RecSubSubF_sf.h"
  #include "RecSubSubF_sfcn_rtw\RecSubSubF_sf_private.h"

#endif
