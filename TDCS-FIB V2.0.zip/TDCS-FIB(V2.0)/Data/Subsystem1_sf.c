/*
 * Generated S-function Target for model Subsystem1. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Tue Jul 04 15:10:17 2017
 */

#include "Subsystem1_sf.h"
#include "Subsystem1_sfcn_rtw\Subsystem1_sf.c"
#include "Subsystem1_sfcn_rtw\Subsystem1_sf_data.c"


