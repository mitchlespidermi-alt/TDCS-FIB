/*
 * Generated S-function Target for model SBN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:23:00 2017
 */

#include "SBN_sf.h"
#include "SBN_sfcn_rtw\SBN_sf.c"


