/*
* Generated S-function Target for model IntermediateDClinkF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:17:59 2017
*/

#ifndef RTWSFCN_IntermediateDClinkF_sf_H
#define RTWSFCN_IntermediateDClinkF_sf_H

#include "IntermediateDClinkF_sfcn_rtw\IntermediateDClinkF_sf.h"
  #include "IntermediateDClinkF_sfcn_rtw\IntermediateDClinkF_sf_private.h"

#endif
