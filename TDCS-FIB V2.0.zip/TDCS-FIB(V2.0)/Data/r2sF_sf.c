/*
 * Generated S-function Target for model r2sF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Jul 24 15:35:53 2017
 */

#include "r2sF_sf.h"
#include "r2sF_sfcn_rtw\r2sF_sf.c"


