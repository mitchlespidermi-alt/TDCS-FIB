/*
 * Generated S-function Target for model InverterTvF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 10:50:47 2017
 */

#include "InverterTvF_sf.h"
#include "InverterTvF_sfcn_rtw\InverterTvF_sf.c"


