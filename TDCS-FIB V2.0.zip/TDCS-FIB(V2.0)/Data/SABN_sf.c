/*
 * Generated S-function Target for model SABN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:23:20 2017
 */

#include "SABN_sf.h"
#include "SABN_sfcn_rtw\SABN_sf.c"


