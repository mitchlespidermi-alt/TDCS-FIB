/*
* Generated S-function Target for model IntermediateDClinkN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:25:25 2017
*/

#ifndef RTWSFCN_IntermediateDClinkN_sf_H
#define RTWSFCN_IntermediateDClinkN_sf_H

#include "IntermediateDClinkN_sfcn_rtw\IntermediateDClinkN_sf.h"
  #include "IntermediateDClinkN_sfcn_rtw\IntermediateDClinkN_sf_private.h"

#endif
