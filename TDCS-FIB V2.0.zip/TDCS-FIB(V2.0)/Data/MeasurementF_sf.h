/*
* Generated S-function Target for model MeasurementF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:18:47 2017
*/

#ifndef RTWSFCN_MeasurementF_sf_H
#define RTWSFCN_MeasurementF_sf_H

#include "MeasurementF_sfcn_rtw\MeasurementF_sf.h"
  #include "MeasurementF_sfcn_rtw\MeasurementF_sf_private.h"

#endif
