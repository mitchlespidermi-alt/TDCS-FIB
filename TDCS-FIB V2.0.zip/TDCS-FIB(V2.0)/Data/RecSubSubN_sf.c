/*
 * Generated S-function Target for model RecSubSubN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:23:45 2017
 */

#include "RecSubSubN_sf.h"
#include "RecSubSubN_sfcn_rtw\RecSubSubN_sf.c"


