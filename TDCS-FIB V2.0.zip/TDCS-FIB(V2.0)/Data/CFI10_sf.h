/*
* Generated S-function Target for model CFI10. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Apr 08 09:38:52 2016
*/

#ifndef RTWSFCN_CFI10_sf_H
#define RTWSFCN_CFI10_sf_H

#include "CFI10_sfcn_rtw\CFI10_sf.h"
  #include "CFI10_sfcn_rtw\CFI10_sf_private.h"

#endif
