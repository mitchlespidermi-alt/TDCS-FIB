/*
* Generated S-function Target for model r2sF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon Jul 24 15:35:53 2017
*/

#ifndef RTWSFCN_r2sF_sf_H
#define RTWSFCN_r2sF_sf_H

#include "r2sF_sfcn_rtw\r2sF_sf.h"
  #include "r2sF_sfcn_rtw\r2sF_sf_private.h"

#endif
