/*
 * Generated S-function Target for model MFI. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Wed Apr 06 14:57:21 2016
 */

#include "MFI_sf.h"
#include "MFI_sfcn_rtw\MFI_sf.c"
#include "MFI_sfcn_rtw\MFI_sf_data.c"


