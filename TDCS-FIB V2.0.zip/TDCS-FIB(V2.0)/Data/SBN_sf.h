/*
* Generated S-function Target for model SBN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:23:00 2017
*/

#ifndef RTWSFCN_SBN_sf_H
#define RTWSFCN_SBN_sf_H

#include "SBN_sfcn_rtw\SBN_sf.h"
  #include "SBN_sfcn_rtw\SBN_sf_private.h"

#endif
