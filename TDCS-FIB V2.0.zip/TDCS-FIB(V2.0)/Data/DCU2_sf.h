/*
* Generated S-function Target for model DCU2. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon Oct 31 17:24:19 2016
*/

#ifndef RTWSFCN_DCU2_sf_H
#define RTWSFCN_DCU2_sf_H

#include "DCU2_sfcn_rtw\DCU2_sf.h"
  #include "DCU2_sfcn_rtw\DCU2_sf_private.h"

#endif
