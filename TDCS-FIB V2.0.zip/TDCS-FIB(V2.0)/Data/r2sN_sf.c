/*
 * Generated S-function Target for model r2sN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Jul 24 15:37:15 2017
 */

#include "r2sN_sf.h"
#include "r2sN_sfcn_rtw\r2sN_sf.c"


