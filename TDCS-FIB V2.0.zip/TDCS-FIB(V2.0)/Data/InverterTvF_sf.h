/*
* Generated S-function Target for model InverterTvF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 10:50:47 2017
*/

#ifndef RTWSFCN_InverterTvF_sf_H
#define RTWSFCN_InverterTvF_sf_H

#include "InverterTvF_sfcn_rtw\InverterTvF_sf.h"
  #include "InverterTvF_sfcn_rtw\InverterTvF_sf_private.h"

#endif
