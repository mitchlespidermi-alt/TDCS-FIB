/*
* Generated S-function Target for model SABF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:16:21 2017
*/

#ifndef RTWSFCN_SABF_sf_H
#define RTWSFCN_SABF_sf_H

#include "SABF_sfcn_rtw\SABF_sf.h"
  #include "SABF_sfcn_rtw\SABF_sf_private.h"

#endif
