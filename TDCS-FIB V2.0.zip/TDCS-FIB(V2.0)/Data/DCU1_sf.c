/*
 * Generated S-function Target for model DCU1. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Oct 31 17:21:50 2016
 */

#include "DCU1_sf.h"
#include "DCU1_sfcn_rtw\DCU1_sf.c"
#include "DCU1_sfcn_rtw\DCU1_sf_data.c"


