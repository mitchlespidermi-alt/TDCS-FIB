/*
 * Generated S-function Target for model CFI10. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Apr 08 09:38:52 2016
 */

#include "CFI10_sf.h"
#include "CFI10_sfcn_rtw\CFI10_sf.c"
#include "CFI10_sfcn_rtw\CFI10_sf_data.c"


