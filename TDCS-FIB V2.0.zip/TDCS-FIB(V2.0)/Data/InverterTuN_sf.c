/*
 * Generated S-function Target for model InverterTuN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:24:22 2017
 */

#include "InverterTuN_sf.h"
#include "InverterTuN_sfcn_rtw\InverterTuN_sf.c"


