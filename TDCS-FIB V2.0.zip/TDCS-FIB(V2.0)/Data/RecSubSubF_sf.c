/*
 * Generated S-function Target for model RecSubSubF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:16:51 2017
 */

#include "RecSubSubF_sf.h"
#include "RecSubSubF_sfcn_rtw\RecSubSubF_sf.c"


