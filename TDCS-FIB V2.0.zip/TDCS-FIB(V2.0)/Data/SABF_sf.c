/*
 * Generated S-function Target for model SABF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:16:21 2017
 */

#include "SABF_sf.h"
#include "SABF_sfcn_rtw\SABF_sf.c"


