/*
 * Generated S-function Target for model SBF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:16:01 2017
 */

#include "SBF_sf.h"
#include "SBF_sfcn_rtw\SBF_sf.c"


