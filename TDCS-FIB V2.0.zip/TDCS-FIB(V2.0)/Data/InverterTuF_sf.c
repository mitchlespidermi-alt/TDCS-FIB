/*
 * Generated S-function Target for model InverterTuF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 10:46:42 2017
 */

#include "InverterTuF_sf.h"
#include "InverterTuF_sfcn_rtw\InverterTuF_sf.c"


