/*
* Generated S-function Target for model Subsystem1. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Tue Jul 04 15:10:17 2017
*/

#ifndef RTWSFCN_Subsystem1_sf_H
#define RTWSFCN_Subsystem1_sf_H

#include "Subsystem1_sfcn_rtw\Subsystem1_sf.h"
  #include "Subsystem1_sfcn_rtw\Subsystem1_sf_private.h"

#endif
