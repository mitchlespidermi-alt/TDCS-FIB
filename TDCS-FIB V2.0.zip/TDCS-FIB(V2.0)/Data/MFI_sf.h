/*
* Generated S-function Target for model MFI. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Wed Apr 06 14:57:21 2016
*/

#ifndef RTWSFCN_MFI_sf_H
#define RTWSFCN_MFI_sf_H

#include "MFI_sfcn_rtw\MFI_sf.h"
  #include "MFI_sfcn_rtw\MFI_sf_private.h"

#endif
