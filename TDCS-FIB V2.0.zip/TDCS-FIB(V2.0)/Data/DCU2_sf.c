/*
 * Generated S-function Target for model DCU2. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Mon Oct 31 17:24:19 2016
 */

#include "DCU2_sf.h"
#include "DCU2_sfcn_rtw\DCU2_sf.c"
#include "DCU2_sfcn_rtw\DCU2_sf_data.c"


