/*
* Generated S-function Target for model SFI0. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Wed Apr 06 14:43:03 2016
*/

#ifndef RTWSFCN_SFI0_sf_H
#define RTWSFCN_SFI0_sf_H

#include "SFI0_sfcn_rtw\SFI0_sf.h"
  #include "SFI0_sfcn_rtw\SFI0_sf_private.h"

#endif
