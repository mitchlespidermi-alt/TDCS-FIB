/*
 * Generated S-function Target for model SAN. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:22:40 2017
 */

#include "SAN_sf.h"
#include "SAN_sfcn_rtw\SAN_sf.c"


