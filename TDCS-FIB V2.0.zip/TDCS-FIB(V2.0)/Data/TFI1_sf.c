/*
 * Generated S-function Target for model TFI1. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Wed Apr 06 20:55:06 2016
 */

#include "TFI1_sf.h"
#include "TFI1_sfcn_rtw\TFI1_sf.c"
#include "TFI1_sfcn_rtw\TFI1_sf_data.c"


