/*
* Generated S-function Target for model SBF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:16:01 2017
*/

#ifndef RTWSFCN_SBF_sf_H
#define RTWSFCN_SBF_sf_H

#include "SBF_sfcn_rtw\SBF_sf.h"
  #include "SBF_sfcn_rtw\SBF_sf_private.h"

#endif
