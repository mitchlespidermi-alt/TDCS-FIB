/*
* Generated S-function Target for model InverterTvN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:24:41 2017
*/

#ifndef RTWSFCN_InverterTvN_sf_H
#define RTWSFCN_InverterTvN_sf_H

#include "InverterTvN_sfcn_rtw\InverterTvN_sf.h"
  #include "InverterTvN_sfcn_rtw\InverterTvN_sf_private.h"

#endif
