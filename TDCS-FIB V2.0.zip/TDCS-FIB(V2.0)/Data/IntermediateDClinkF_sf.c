/*
 * Generated S-function Target for model IntermediateDClinkF. 
 * This source file provides access to the generated S-function target
 * for other models.
 *
 * Created: Fri Jul 21 16:17:59 2017
 */

#include "IntermediateDClinkF_sf.h"
#include "IntermediateDClinkF_sfcn_rtw\IntermediateDClinkF_sf.c"


