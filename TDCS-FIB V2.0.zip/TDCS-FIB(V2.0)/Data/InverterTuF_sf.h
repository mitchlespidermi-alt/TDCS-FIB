/*
* Generated S-function Target for model InverterTuF. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 10:46:42 2017
*/

#ifndef RTWSFCN_InverterTuF_sf_H
#define RTWSFCN_InverterTuF_sf_H

#include "InverterTuF_sfcn_rtw\InverterTuF_sf.h"
  #include "InverterTuF_sfcn_rtw\InverterTuF_sf_private.h"

#endif
