/*
* Generated S-function Target for model InverterTwN. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Fri Jul 21 16:24:58 2017
*/

#ifndef RTWSFCN_InverterTwN_sf_H
#define RTWSFCN_InverterTwN_sf_H

#include "InverterTwN_sfcn_rtw\InverterTwN_sf.h"
  #include "InverterTwN_sfcn_rtw\InverterTwN_sf_private.h"

#endif
