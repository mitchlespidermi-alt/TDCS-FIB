/*
* Generated S-function Target for model TFI1. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Wed Apr 06 20:55:06 2016
*/

#ifndef RTWSFCN_TFI1_sf_H
#define RTWSFCN_TFI1_sf_H

#include "TFI1_sfcn_rtw\TFI1_sf.h"
  #include "TFI1_sfcn_rtw\TFI1_sf_private.h"

#endif
