/*
* Generated S-function Target for model DCU1. 
* This file provides access to the generated S-function target
* export file for other models.
*
* Created: Mon Oct 31 17:21:50 2016
*/

#ifndef RTWSFCN_DCU1_sf_H
#define RTWSFCN_DCU1_sf_H

#include "DCU1_sfcn_rtw\DCU1_sf.h"
  #include "DCU1_sfcn_rtw\DCU1_sf_private.h"

#endif
